/* =========================================================
   VÍAS · FOTOS POR PROGRESIVA  —  Codigo.gs  (servidor / API)
   La app se instala en el celular y trabaja sin señal;
   este archivo guarda vías, ejes, usuarios y fotos (Hoja + Drive).
   ========================================================= */

/* ---------- CONFIGURACIÓN EDITABLE ---------- */
var APP_NOMBRE       = 'VÍAS · Fotos por progresiva';
var APP_SIGLA        = 'BJHP';
var DIRECTOR_USUARIO = 'director';
var DIRECTOR_NOMBRE  = 'Ing. Bladimir J. Huaynasi Pari';
var DIRECTOR_CLAVE   = 'Vias2026';          /* cámbiela antes de ejecutar instalar() */
var CARPETA_RAIZ     = 'VIAS - Fotos por progresiva';
var DIAS_SESION      = 30;                  /* días que el celular queda con sesión abierta (para trabajar sin señal) */

/* ---------- HOJAS ---------- */
var H_VIAS = 'Vias', H_EJE = 'Eje', H_FOTOS = 'Fotos', H_USU = 'Usuarios', H_HIS = 'Historial';
var CAB = {
  Vias:      ['id','nombre','codigo','zona','dE','dN','progIni','progFin','puntos','carpetaId','actualizado','usuario'],
  Eje:       ['viaId','prog','este','norte','cota'],
  Fotos:     ['id','fechaHora','viaId','via','prog','progTxt','lado','distEje','este','norte','lat','lon','precision','capa','descripcion','usuario','archivoId','url','obs','cotaEje','altGps','lugar'],
  Usuarios:  ['usuario','claveHash','nombre','rol','activo'],
  Historial: ['fechaHora','usuario','accion','detalle']
};

/* Ejecutar UNA vez desde el editor */
function instalar() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  Object.keys(CAB).forEach(function (n) {
    var h = ss.getSheetByName(n);
    if (!h) h = ss.insertSheet(n);
    asegurarCab_(h, n);
  });
  ss.getSheetByName(H_FOTOS).getRange('F:F').setNumberFormat('@');
  ss.getSheetByName(H_FOTOS).getRange('B:B').setNumberFormat('@');
  var u = ss.getSheetByName(H_USU), d = u.getDataRange().getValues();
  var existe = d.some(function (r) { return String(r[0]).toLowerCase() === DIRECTOR_USUARIO.toLowerCase(); });
  if (!existe) u.appendRow([DIRECTOR_USUARIO, hash_(DIRECTOR_CLAVE), DIRECTOR_NOMBRE, 'Director', true]);
  carpetaRaiz_();
  return 'Instalado correctamente';
}

/* ---------- PUERTA DE ENTRADA (API para la app del celular) ---------- */
var API = {
  login: login, inicio: inicio, obtenerEje: obtenerEje, obtenerEjes: obtenerEjes, guardarVia: guardarVia,
  subirFoto: subirFoto, listarFotos: listarFotos, eliminarFoto: eliminarFoto,
  listarUsuarios: listarUsuarios, guardarUsuario: guardarUsuario
};

function doPost(e) {
  var out;
  try {
    var q = JSON.parse(e.postData.contents);
    if (!API.hasOwnProperty(q.fn)) throw new Error('Función no permitida: ' + q.fn);
    out = { ok: true, r: API[q.fn].apply(null, q.args || []) };
  } catch (err) {
    out = { ok: false, e: (err && err.message) ? err.message : String(err) };
  }
  return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
}

function doGet() {
  return ContentService.createTextOutput(JSON.stringify({ ok: true, app: APP_NOMBRE, estado: 'Servidor activo' }))
    .setMimeType(ContentService.MimeType.JSON);
}

/* ---------- SESIÓN (dura DIAS_SESION para trabajar sin señal) ---------- */
function login(usuario, clave) {
  var d = hoja_(H_USU).getDataRange().getValues();
  var u = String(usuario || '').trim().toLowerCase(), h = hash_(clave);
  for (var i = 1; i < d.length; i++) {
    if (String(d[i][0]).toLowerCase() === u && d[i][1] === h && activo_(d[i][4])) {
      limpiarSesiones_();
      var tok = Utilities.getUuid();
      var s = { u: String(d[i][0]), n: String(d[i][2]), r: String(d[i][3]), exp: Date.now() + DIAS_SESION * 86400000 };
      PropertiesService.getScriptProperties().setProperty('S_' + tok, JSON.stringify(s));
      log_(d[i][0], 'Ingreso', '');
      return { token: tok };
    }
  }
  throw new Error('Usuario o clave incorrectos');
}

function ses_(tok, roles) {
  var p = PropertiesService.getScriptProperties(), raw = tok ? p.getProperty('S_' + tok) : null;
  if (!raw) throw new Error('SESION_VENCIDA');
  var o = JSON.parse(raw);
  if (o.exp < Date.now()) { p.deleteProperty('S_' + tok); throw new Error('SESION_VENCIDA'); }
  if (o.exp - Date.now() < (DIAS_SESION - 1) * 86400000) {           /* renovar una vez al día */
    o.exp = Date.now() + DIAS_SESION * 86400000;
    p.setProperty('S_' + tok, JSON.stringify(o));
  }
  if (roles && roles.indexOf(o.r) < 0) throw new Error('Su rol (' + o.r + ') no permite esta acción');
  return o;
}

function limpiarSesiones_() {
  var p = PropertiesService.getScriptProperties(), all = p.getProperties(), ahora = Date.now();
  Object.keys(all).forEach(function (k) {
    if (k.indexOf('S_') !== 0) return;
    try { if (JSON.parse(all[k]).exp < ahora) p.deleteProperty(k); } catch (e) { p.deleteProperty(k); }
  });
}

function inicio(tok) {
  var s = ses_(tok);
  return { usuario: s.u, nombre: s.n, rol: s.r, app: APP_NOMBRE, sigla: APP_SIGLA, vias: listarVias_() };
}

/* ---------- VÍAS Y EJES ---------- */
function listarVias_() {
  var d = hoja_(H_VIAS).getDataRange().getValues(), out = [];
  for (var i = 1; i < d.length; i++) {
    if (!d[i][0]) continue;
    out.push({
      id: String(d[i][0]), nombre: String(d[i][1]), codigo: String(d[i][2] || ''),
      zona: Number(d[i][3]) || 18, dE: Number(d[i][4]) || 0, dN: Number(d[i][5]) || 0,
      progIni: Number(d[i][6]) || 0, progFin: Number(d[i][7]) || 0, puntos: Number(d[i][8]) || 0,
      actualizado: val_(d[i][10]), usuario: String(d[i][11] || '')
    });
  }
  out.sort(function (a, b) { return a.nombre.localeCompare(b.nombre); });
  return out;
}

function obtenerEje(tok, viaId) {
  ses_(tok);
  return obtenerEjes_()[String(viaId)] || [];
}

/* Todos los ejes de una vez (para guardarlos en el celular) */
function obtenerEjes(tok) {
  ses_(tok);
  return obtenerEjes_();
}

function obtenerEjes_() {
  var d = hoja_(H_EJE).getDataRange().getValues(), m = {};
  for (var i = 1; i < d.length; i++) {
    var id = String(d[i][0]); if (!id) continue;
    (m[id] = m[id] || []).push([Number(d[i][1]), Number(d[i][2]), Number(d[i][3]), cotaNum_(d[i][4])]);
  }
  Object.keys(m).forEach(function (k) { m[k].sort(function (a, b) { return a[0] - b[0]; }); });
  return m;
}

function guardarVia(tok, via, puntos) {
  var s = ses_(tok, ['Director', 'Supervisor']);
  var lock = LockService.getScriptLock(); lock.waitLock(30000);
  try {
    var hv = hoja_(H_VIAS), d = hv.getDataRange().getValues(), fila = -1;
    var id = via.id || ('V' + new Date().getTime().toString(36).toUpperCase());
    for (var i = 1; i < d.length; i++) if (String(d[i][0]) === id) { fila = i + 1; break; }
    var ant = fila > 0 ? d[fila - 1] : null;

    var carpetaId = ant ? ant[9] : '';
    try {
      if (carpetaId) DriveApp.getFolderById(carpetaId).setName(via.nombre);
      else carpetaId = carpetaRaiz_().createFolder(via.nombre).getId();
    } catch (e) { carpetaId = carpetaRaiz_().createFolder(via.nombre).getId(); }

    var progIni = ant ? ant[6] : 0, progFin = ant ? ant[7] : 0, n = ant ? ant[8] : 0;
    if (puntos && puntos.length) {
      var he = hoja_(H_EJE), de = he.getDataRange().getValues(), keep = [CAB.Eje];
      for (var j = 1; j < de.length; j++) {
        if (String(de[j][0]) === id) continue;
        var f = de[j].slice(0, 5); while (f.length < 5) f.push('');
        keep.push(f);
      }
      puntos.forEach(function (p) { var c = cotaNum_(p[3]); keep.push([id, Number(p[0]), Number(p[1]), Number(p[2]), c === null ? '' : c]); });
      he.clearContents();
      he.getRange(1, 1, keep.length, 5).setValues(keep);
      he.getRange(1, 1, 1, 5).setFontWeight('bold').setBackground('#b3121f').setFontColor('#ffffff');
      progIni = Number(puntos[0][0]); progFin = Number(puntos[puntos.length - 1][0]); n = puntos.length;
    } else if (!ant) {
      throw new Error('Faltan las coordenadas del eje');
    }

    var filaDatos = [id, via.nombre, via.codigo || '', Number(via.zona) || 18, Number(via.dE) || 0, Number(via.dN) || 0,
      progIni, progFin, n, carpetaId, new Date(), s.u];
    if (fila > 0) hv.getRange(fila, 1, 1, filaDatos.length).setValues([filaDatos]);
    else hv.appendRow(filaDatos);
    log_(s.u, fila > 0 ? 'Edita vía' : 'Nueva vía', via.nombre + (puntos ? ' · ' + puntos.length + ' puntos de eje' : ''));
    return { id: id, vias: listarVias_() };
  } finally { lock.releaseLock(); }
}

/* ---------- FOTOS ---------- */
function subirFoto(tok, r, b64) {
  var s = ses_(tok, ['Director', 'Supervisor', 'Residente', 'Asistente']);
  var hf = hoja_(H_FOTOS);
  asegurarCab_(hf, H_FOTOS);

  /* Si la foto ya llegó antes (se cortó la señal en la respuesta), no la duplica */
  if (r.uid) {
    var ids = hf.getRange(1, 1, Math.max(1, hf.getLastRow()), 1).getValues();
    for (var k = 1; k < ids.length; k++) if (String(ids[k][0]) === String(r.uid)) return { id: r.uid, repetida: true };
  }

  var via = null;
  listarVias_().forEach(function (v) { if (v.id === String(r.viaId)) via = v; });
  if (!via) throw new Error('Carretera no encontrada');

  var carpeta = carpetaVia_(r.viaId);
  var nombre = (via.codigo || 'VIA') + '_' + r.progTxt + '_' + r.lado + '_' + String(r.fechaHora).replace(/[^0-9]/g, '').slice(0, 12) + '.jpg';
  var blob = Utilities.newBlob(Utilities.base64Decode(b64), 'image/jpeg', nombre);
  var f = carpeta.createFile(blob);
  try { f.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); } catch (e) { }
  f.setDescription(via.nombre + ' · Prog. ' + r.progTxt + (r.cotaEje !== '' && r.cotaEje !== null && r.cotaEje !== undefined ? ' · Cota ' + r.cotaEje : '') + ' · ' + r.capa + (r.descripcion ? ' · ' + r.descripcion : ''));

  var id = r.uid || ('F' + new Date().getTime().toString(36).toUpperCase() + Math.floor(Math.random() * 1000));
  var lock = LockService.getScriptLock(); lock.waitLock(30000);
  try {
    hf.appendRow([id, r.fechaHora, via.id, via.nombre, r.prog, r.progTxt, r.lado, r.distEje, r.este, r.norte,
      r.lat, r.lon, r.precision, r.capa, r.descripcion, s.n, f.getId(), f.getUrl(), r.obs || '',
      nn_(r.cotaEje, ''), nn_(r.altGps, ''), r.lugar || '']);
  } finally { lock.releaseLock(); }
  log_(s.u, 'Foto', via.nombre + ' · ' + r.progTxt);
  return { id: id, archivoId: f.getId(), url: f.getUrl() };
}

function listarFotos(tok, viaId) {
  ses_(tok);
  var d = hoja_(H_FOTOS).getDataRange().getValues(), c = CAB.Fotos, out = [];
  for (var i = 1; i < d.length; i++) {
    if (String(d[i][2]) !== String(viaId)) continue;
    var o = {};
    for (var j = 0; j < c.length; j++) o[c[j]] = val_(d[i][j]);
    out.push(o);
  }
  return out;
}

function eliminarFoto(tok, id) {
  var s = ses_(tok, ['Director']);
  var h = hoja_(H_FOTOS), d = h.getDataRange().getValues();
  for (var i = 1; i < d.length; i++) {
    if (String(d[i][0]) === String(id)) {
      try { DriveApp.getFileById(d[i][16]).setTrashed(true); } catch (e) { }
      h.deleteRow(i + 1);
      log_(s.u, 'Elimina foto', d[i][3] + ' · ' + d[i][5]);
      return true;
    }
  }
  throw new Error('Foto no encontrada');
}

/* ---------- USUARIOS ---------- */
function listarUsuarios(tok) {
  ses_(tok, ['Director']);
  var d = hoja_(H_USU).getDataRange().getValues(), o = [];
  for (var i = 1; i < d.length; i++) if (d[i][0]) o.push({ usuario: String(d[i][0]), nombre: String(d[i][2]), rol: String(d[i][3]), activo: activo_(d[i][4]) });
  return o;
}

function guardarUsuario(tok, u) {
  var s = ses_(tok, ['Director']);
  var h = hoja_(H_USU), d = h.getDataRange().getValues(), usu = String(u.usuario || '').trim();
  if (!usu) throw new Error('Escriba el usuario');
  for (var i = 1; i < d.length; i++) {
    if (String(d[i][0]).toLowerCase() === usu.toLowerCase()) {
      h.getRange(i + 1, 3, 1, 3).setValues([[u.nombre, u.rol, !!u.activo]]);
      if (u.clave) h.getRange(i + 1, 2).setValue(hash_(u.clave));
      log_(s.u, 'Edita usuario', usu);
      return listarUsuarios(tok);
    }
  }
  if (!u.clave) throw new Error('Asigne una clave al nuevo usuario');
  h.appendRow([usu, hash_(u.clave), u.nombre, u.rol, !!u.activo]);
  log_(s.u, 'Nuevo usuario', usu);
  return listarUsuarios(tok);
}

/* ---------- AUXILIARES ---------- */
/* Pone (o amplía) la fila de títulos de una hoja; sirve para hojas creadas con versiones anteriores */
function asegurarCab_(h, n) {
  var c = CAB[n];
  if (h.getLastRow() === 0 || h.getLastColumn() < c.length) {
    h.getRange(1, 1, 1, c.length).setValues([c]).setFontWeight('bold').setBackground('#b3121f').setFontColor('#ffffff');
    h.setFrozenRows(1);
  }
}
function cotaNum_(v) { return (v === '' || v === null || v === undefined || isNaN(Number(v))) ? null : Number(v); }
function hoja_(n) {
  var h = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(n);
  if (!h) throw new Error('Falta la hoja "' + n + '". Ejecute instalar() en el editor.');
  return h;
}
function carpetaRaiz_() {
  var p = PropertiesService.getScriptProperties(), id = p.getProperty('CARPETA_RAIZ');
  if (id) { try { return DriveApp.getFolderById(id); } catch (e) { } }
  var f = DriveApp.createFolder(CARPETA_RAIZ);
  p.setProperty('CARPETA_RAIZ', f.getId());
  return f;
}
function carpetaVia_(viaId) {
  var h = hoja_(H_VIAS), d = h.getDataRange().getValues();
  for (var i = 1; i < d.length; i++) {
    if (String(d[i][0]) === String(viaId)) {
      if (d[i][9]) { try { return DriveApp.getFolderById(d[i][9]); } catch (e) { } }
      var f = carpetaRaiz_().createFolder(String(d[i][1]));
      h.getRange(i + 1, 10).setValue(f.getId());
      return f;
    }
  }
  throw new Error('Carretera no encontrada');
}
function nn_(a, b) { return (a === undefined || a === null) ? b : a; }
function activo_(v) { return !(v === false || String(v).toUpperCase() === 'FALSE'); }
function val_(x) {
  if (x instanceof Date) return Utilities.formatDate(x, Session.getScriptTimeZone(), 'dd/MM/yyyy HH:mm');
  return x;
}
function hash_(t) {
  var b = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, String(t), Utilities.Charset.UTF_8);
  return b.map(function (x) { var v = (x < 0 ? x + 256 : x).toString(16); return v.length < 2 ? '0' + v : v; }).join('');
}
function log_(u, a, det) {
  try { hoja_(H_HIS).appendRow([new Date(), u, a, det]); } catch (e) { }
}
